import React, { useState } from 'react';
import { Truck, Recycle, Calendar, Award, BarChart3 } from 'lucide-react';
import SchedulePickup from './components/SchedulePickup';
import Dashboard from './components/Dashboard';
import RecyclingPoints from './components/RecyclingPoints';

function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'schedule' | 'points'>('dashboard');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-green-600 to-emerald-600">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Recycle className="w-8 h-8 text-white" />
              <h1 className="text-2xl font-bold text-white">EcoCollect</h1>
            </div>
            <nav className="hidden md:flex space-x-4">
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`px-4 py-2 rounded-lg text-white ${
                  activeTab === 'dashboard' ? 'bg-white/20' : 'hover:bg-white/10'
                }`}
              >
                Dashboard
              </button>
              <button
                onClick={() => setActiveTab('schedule')}
                className={`px-4 py-2 rounded-lg text-white ${
                  activeTab === 'schedule' ? 'bg-white/20' : 'hover:bg-white/10'
                }`}
              >
                Schedule Pickup
              </button>
              <button
                onClick={() => setActiveTab('points')}
                className={`px-4 py-2 rounded-lg text-white ${
                  activeTab === 'points' ? 'bg-white/20' : 'hover:bg-white/10'
                }`}
              >
                Recycling Points
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {activeTab === 'dashboard' && <Dashboard />}
        {activeTab === 'schedule' && <SchedulePickup />}
        {activeTab === 'points' && <RecyclingPoints />}
      </main>

      {/* Features Section */}
      <section className="bg-white py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose EcoCollect?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-6 rounded-lg border border-gray-200 hover:shadow-lg transition-shadow">
              <Truck className="w-12 h-12 text-green-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Efficient Collection</h3>
              <p className="text-gray-600">
                Schedule waste pickups at your convenience with our optimized collection routes.
              </p>
            </div>
            
            <div className="p-6 rounded-lg border border-gray-200 hover:shadow-lg transition-shadow">
              <Award className="w-12 h-12 text-green-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Rewards Program</h3>
              <p className="text-gray-600">
                Earn points for recycling and responsible waste management practices.
              </p>
            </div>
            
            <div className="p-6 rounded-lg border border-gray-200 hover:shadow-lg transition-shadow">
              <BarChart3 className="w-12 h-12 text-green-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Impact Tracking</h3>
              <p className="text-gray-600">
                Monitor your environmental impact with detailed waste management analytics.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default App;