import React, { useState } from 'react';
import { Search, MapPin } from 'lucide-react';
import type { SearchFilters } from '../types';

interface SearchBoxProps {
  onSearch: (filters: SearchFilters) => void;
}

export default function SearchBox({ onSearch }: SearchBoxProps) {
  const [filters, setFilters] = useState<SearchFilters>({
    location: '',
    foodType: ''
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(filters);
  };

  return (
    <div className="max-w-2xl mx-auto">
      <form onSubmit={handleSearch} className="bg-white p-4 rounded-lg shadow-lg">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="Location"
              className="w-full pl-10 pr-3 py-2 rounded-md border border-gray-300 focus:border-orange-500 focus:ring-orange-500"
              value={filters.location}
              onChange={(e) => setFilters({...filters, location: e.target.value})}
            />
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
          </div>
          
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="Food type (e.g., Pani Puri)"
              className="w-full pl-10 pr-3 py-2 rounded-md border border-gray-300 focus:border-orange-500 focus:ring-orange-500"
              value={filters.foodType}
              onChange={(e) => setFilters({...filters, foodType: e.target.value})}
            />
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
          </div>
          
          <button
            type="submit"
            className="bg-orange-500 text-white px-6 py-2 rounded-md hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2"
          >
            Search
          </button>
        </div>
      </form>
    </div>
  );
}