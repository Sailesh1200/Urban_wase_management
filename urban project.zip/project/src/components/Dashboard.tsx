import React from 'react';
import { BarChart3, Truck, Recycle, Award } from 'lucide-react';

export default function Dashboard() {
  // Mock data - In a real app, this would come from an API
  const stats = {
    totalPickups: 24,
    recyclingRate: 75,
    pointsEarned: 1250,
    carbonSaved: 450
  };

  const recentPickups = [
    {
      id: '1',
      date: '2024-03-15',
      status: 'completed',
      wasteTypes: ['Plastic', 'Paper'],
      points: 50
    },
    {
      id: '2',
      date: '2024-03-10',
      status: 'completed',
      wasteTypes: ['Glass', 'Metal'],
      points: 75
    }
  ];

  return (
    <div className="space-y-8">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Pickups</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalPickups}</p>
            </div>
            <Truck className="w-8 h-8 text-green-600" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Recycling Rate</p>
              <p className="text-2xl font-bold text-gray-900">{stats.recyclingRate}%</p>
            </div>
            <Recycle className="w-8 h-8 text-green-600" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Points Earned</p>
              <p className="text-2xl font-bold text-gray-900">{stats.pointsEarned}</p>
            </div>
            <Award className="w-8 h-8 text-green-600" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Carbon Saved (kg)</p>
              <p className="text-2xl font-bold text-gray-900">{stats.carbonSaved}</p>
            </div>
            <BarChart3 className="w-8 h-8 text-green-600" />
          </div>
        </div>
      </div>

      {/* Recent Pickups */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Pickups</h2>
          <div className="space-y-4">
            {recentPickups.map((pickup) => (
              <div
                key={pickup.id}
                className="flex items-center justify-between p-4 border border-gray-100 rounded-lg"
              >
                <div>
                  <p className="font-medium text-gray-900">
                    {new Date(pickup.date).toLocaleDateString()}
                  </p>
                  <p className="text-sm text-gray-600">
                    {pickup.wasteTypes.join(', ')}
                  </p>
                </div>
                <div className="text-right">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    +{pickup.points} points
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}