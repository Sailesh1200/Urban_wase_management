import React, { useState } from 'react';
import { Calendar, MapPin, Package, ClipboardList } from 'lucide-react';
import type { ScheduleFormData } from '../types';

const wasteTypes = [
  { id: 'plastic', name: 'Plastic', points: 10 },
  { id: 'paper', name: 'Paper', points: 8 },
  { id: 'glass', name: 'Glass', points: 12 },
  { id: 'metal', name: 'Metal', points: 15 },
  { id: 'organic', name: 'Organic', points: 5 },
  { id: 'electronic', name: 'Electronic', points: 20 }
];

export default function SchedulePickup() {
  const [formData, setFormData] = useState<ScheduleFormData>({
    pickupDate: '',
    address: '',
    wasteTypes: [],
    notes: '',
    quantity: 1
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement API call to schedule pickup
    console.log('Scheduling pickup:', formData);
    alert('Pickup scheduled successfully!');
  };

  const handleWasteTypeChange = (typeId: string) => {
    setFormData(prev => ({
      ...prev,
      wasteTypes: prev.wasteTypes.includes(typeId)
        ? prev.wasteTypes.filter(id => id !== typeId)
        : [...prev.wasteTypes, typeId]
    }));
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Schedule a Pickup</h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700">Pickup Date</label>
            <div className="mt-1 relative">
              <input
                type="date"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                value={formData.pickupDate}
                onChange={(e) => setFormData({...formData, pickupDate: e.target.value})}
                required
                min={new Date().toISOString().split('T')[0]}
              />
              <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Pickup Address</label>
            <div className="mt-1 relative">
              <input
                type="text"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                value={formData.address}
                onChange={(e) => setFormData({...formData, address: e.target.value})}
                required
                placeholder="Enter your address"
              />
              <MapPin className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Waste Types</label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {wasteTypes.map((type) => (
                <label
                  key={type.id}
                  className={`flex items-center p-4 border rounded-lg cursor-pointer transition-colors ${
                    formData.wasteTypes.includes(type.id)
                      ? 'border-green-500 bg-green-50'
                      : 'border-gray-200 hover:border-green-200'
                  }`}
                >
                  <input
                    type="checkbox"
                    className="sr-only"
                    checked={formData.wasteTypes.includes(type.id)}
                    onChange={() => handleWasteTypeChange(type.id)}
                  />
                  <span className="text-sm">{type.name}</span>
                  <span className="ml-auto text-xs text-green-600">+{type.points} pts</span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Notes</label>
            <textarea
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
              rows={3}
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              placeholder="Any special instructions or notes for pickup"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Approximate Quantity (bags)</label>
            <div className="mt-1 relative">
              <input
                type="number"
                min="1"
                max="10"
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                value={formData.quantity}
                onChange={(e) => setFormData({...formData, quantity: parseInt(e.target.value, 10)})}
                required
              />
              <Package className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
          >
            Schedule Pickup
          </button>
        </form>
      </div>
    </div>
  );
}