import React from 'react';
import { Award, Gift, ArrowRight } from 'lucide-react';

export default function RecyclingPoints() {
  // Mock data - In a real app, this would come from an API
  const points = 1250;
  const rewards = [
    {
      id: '1',
      name: 'Eco-friendly Shopping Bag',
      points: 500,
      description: 'Reusable shopping bag made from recycled materials'
    },
    {
      id: '2',
      name: 'Plant a Tree',
      points: 1000,
      description: 'We will plant a tree in your name'
    },
    {
      id: '3',
      name: 'Composting Starter Kit',
      points: 1500,
      description: 'Everything you need to start composting at home'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Points Overview */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Your Points</h2>
            <p className="text-gray-600">Earn points for every recycling pickup</p>
          </div>
          <div className="flex items-center space-x-2">
            <Award className="w-8 h-8 text-green-600" />
            <span className="text-3xl font-bold text-green-600">{points}</span>
          </div>
        </div>
      </div>

      {/* Available Rewards */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Available Rewards</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {rewards.map((reward) => (
              <div
                key={reward.id}
                className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-semibold text-gray-900">{reward.name}</h3>
                    <p className="text-sm text-gray-600">{reward.description}</p>
                  </div>
                  <Gift className="w-6 h-6 text-green-600 flex-shrink-0" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-600">
                    {reward.points} points
                  </span>
                  <button
                    className={`flex items-center space-x-1 px-3 py-1 rounded-md text-sm font-medium ${
                      points >= reward.points
                        ? 'bg-green-100 text-green-700 hover:bg-green-200'
                        : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                    }`}
                    disabled={points < reward.points}
                  >
                    <span>Redeem</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}