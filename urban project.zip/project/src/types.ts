export interface WastePickup {
  id: string;
  userId: string;
  status: 'pending' | 'scheduled' | 'completed' | 'cancelled';
  pickupDate: string;
  address: string;
  wasteTypes: WasteType[];
  notes?: string;
  quantity: number;
}

export interface WasteType {
  id: string;
  name: string;
  description: string;
  recyclable: boolean;
  points: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  address: string;
  type: 'household' | 'business';
  points: number;
}

export interface ScheduleFormData {
  pickupDate: string;
  address: string;
  wasteTypes: string[];
  notes: string;
  quantity: number;
}